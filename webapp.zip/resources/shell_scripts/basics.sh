#!/bin/bash
X=5
Y=5
ANS=$((X+Y))
echo "\$x+\$y"=$ANS


