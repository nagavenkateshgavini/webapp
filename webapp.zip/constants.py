import os

PROJECT_ROOT = os.path.abspath(__file__)

REGISTERED_APIS = [
    "/healthz",
    "/v1/user",
    "/v1/user/self",
    "/swagger/",
    "/swagger"
]