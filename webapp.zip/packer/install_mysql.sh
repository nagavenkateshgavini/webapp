#!/bin/bash
set -e

sudo dnf install -y mysql-server
sudo systemctl start mysqld
sudo systemctl enable mysqld

sleep 5

sudo systemctl status mysqld

echo "Printing mysql username from env"
echo $MYSQL_USER

sudo mysql -u root -e "CREATE USER '$MYSQL_USER'@'localhost' IDENTIFIED BY '$MYSQL_PASSWORD';"
sudo mysql -u root -e "GRANT ALL PRIVILEGES ON *.* TO '$MYSQL_USER'@'localhost';"

# Verify mysql version
mysql --version
